### Hi there 👋
>      I am Sisindri Singamsetti alias sisi_tarak 😉



### 🖥 About Mee!

I am Full-stack Web Developer, Tech Lead & Tech Enthusiast from 🛕 India 🇮🇳.

- 🧑🏻‍🎓 | Dip UG @svec'23 CME
- 🎯 | Web Developer @sisitarakk
- 🧑🏻‍💻 | Full Stack Developer
- ✊ | Student Ambassador @Mass Coders


![git](https://github.com/sisi-tarak/sisi-tarak/assets/124027883/5e0032f9-38ae-4ee8-be78-4a0c9e1643eb)


### 👨‍💻 Social Platforms!!

>   - 🫠 | [LinkedIN](https://www.linkedin.com/in/sisitarak/)
>   - 🤩 | [GitHub](https://github.com/sisi-tarak)
>   - 🫣 | [Instagram](https://www.instagram.com/sisi_tarakk/)


