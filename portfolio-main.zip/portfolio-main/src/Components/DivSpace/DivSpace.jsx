import React from "react";
import "./DivSpace.css";

const DivSpace = () => {
  return <div className="container-fluid my-5 divSpace"></div>;
};

export default DivSpace;
